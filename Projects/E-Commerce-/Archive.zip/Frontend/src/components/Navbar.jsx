    import React from 'react'
    import "./Navbar.css"
    import 'remixicon/fonts/remixicon.css'

    const Navbar = () => {
      return (
        <nav>

        <div className='left'>
        <h2>Shopy</h2>
        </div>
        <div>
        <input type="text" />
        </div>
        <div className="right">
            <a href="#"></a>
    <i className="ri-shopping-cart-2-fill"></i>
        </div>
        </nav>
      )
    }
    
    export default Navbar